import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { 
  Bell, 
  AlertTriangle, 
  TrendingUp, 
  Users, 
  DollarSign,
  CheckCheck
} from 'lucide-react';

const notifications = [
  {
    id: 1,
    type: 'warning',
    icon: AlertTriangle,
    color: '#F59E0B',
    title: 'Overspending Alert',
    message: 'You\'ve spent $450 more than your monthly budget for "Food & Dining"',
    time: '5 minutes ago',
    unread: true
  },
  {
    id: 2,
    type: 'info',
    icon: DollarSign,
    color: '#22D3EE',
    title: 'Payment Reminder',
    message: 'Your electricity bill of $150 is due in 3 days',
    time: '1 hour ago',
    unread: true
  },
  {
    id: 3,
    type: 'success',
    icon: TrendingUp,
    color: '#10B981',
    title: 'Goal Achievement',
    message: 'Congratulations! You\'ve reached 80% of your "Emergency Fund" goal',
    time: '2 hours ago',
    unread: true
  },
  {
    id: 4,
    type: 'group',
    icon: Users,
    color: '#7C3AED',
    title: 'Group Expense Update',
    message: 'Jane Smith added a new expense of $45 in "Roommates" group',
    time: '5 hours ago',
    unread: false
  },
  {
    id: 5,
    type: 'info',
    icon: Bell,
    color: '#22D3EE',
    title: 'Monthly Report Ready',
    message: 'Your financial report for March 2026 is now available',
    time: '1 day ago',
    unread: false
  },
  {
    id: 6,
    type: 'group',
    icon: Users,
    color: '#7C3AED',
    title: 'Settlement Request',
    message: 'Mike Johnson settled up $120 in "Weekend Trip" group',
    time: '1 day ago',
    unread: false
  },
  {
    id: 7,
    type: 'warning',
    icon: AlertTriangle,
    color: '#F59E0B',
    title: 'Budget Warning',
    message: 'You\'re at 90% of your monthly shopping budget',
    time: '2 days ago',
    unread: false
  },
  {
    id: 8,
    type: 'success',
    icon: TrendingUp,
    color: '#10B981',
    title: 'Investment Update',
    message: 'Your portfolio gained $420 this week (+0.8%)',
    time: '3 days ago',
    unread: false
  },
];

export function Notifications() {
  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Notifications</h1>
            <p className="text-[#94A3B8]">
              {unreadCount > 0 ? `${unreadCount} unread notifications` : 'All caught up!'}
            </p>
          </div>
          <Button variant="secondary">
            <CheckCheck className="w-5 h-5 mr-2" />
            Mark All as Read
          </Button>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`${
                notification.unread
                  ? 'border-l-4 border-l-[#7C3AED]'
                  : 'opacity-70'
              }`}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${notification.color}20` }}
                >
                  <notification.icon
                    className="w-6 h-6"
                    style={{ color: notification.color }}
                  />
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className="text-lg text-[#EDE9FE]">{notification.title}</h3>
                    {notification.unread && (
                      <span className="w-2 h-2 bg-[#7C3AED] rounded-full"></span>
                    )}
                  </div>
                  <p className="text-[#94A3B8] mb-2">{notification.message}</p>
                  <p className="text-sm text-[#94A3B8]">{notification.time}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State (if no notifications) */}
        {notifications.length === 0 && (
          <Card className="text-center py-16">
            <Bell className="w-16 h-16 text-[#94A3B8] mx-auto mb-4 opacity-50" />
            <h3 className="text-xl text-[#EDE9FE] mb-2">No Notifications</h3>
            <p className="text-[#94A3B8]">You're all caught up! Check back later.</p>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
