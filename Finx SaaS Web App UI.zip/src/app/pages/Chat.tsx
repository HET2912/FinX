import { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Send, Search, User } from 'lucide-react';

const chats = [
  { id: 1, name: 'Jane Smith', lastMessage: 'Did you pay the electricity bill?', time: '2m ago', unread: 2, active: true },
  { id: 2, name: 'Roommates Group', lastMessage: 'Mike: Thanks for covering the groceries!', time: '1h ago', unread: 0, active: false },
  { id: 3, name: 'Mike Johnson', lastMessage: 'I\'ll transfer my share tomorrow', time: '3h ago', unread: 0, active: false },
  { id: 4, name: 'Weekend Trip', lastMessage: 'Sarah: Flight tickets booked!', time: '1d ago', unread: 5, active: false },
  { id: 5, name: 'Sarah Williams', lastMessage: 'Can you send me the receipt?', time: '2d ago', unread: 0, active: false },
];

const messages = [
  { id: 1, sender: 'Jane Smith', text: 'Hey! Did you see the electricity bill?', time: '10:30 AM', isMe: false },
  { id: 2, sender: 'You', text: 'Yes, I just paid it. $150 total.', time: '10:32 AM', isMe: true },
  { id: 3, sender: 'Jane Smith', text: 'Great! So $37.50 each for 4 people?', time: '10:33 AM', isMe: false },
  { id: 4, sender: 'You', text: 'Exactly! I\'ll add it to the group expense tracker.', time: '10:35 AM', isMe: true },
  { id: 5, sender: 'Jane Smith', text: 'Perfect. I\'ll transfer my share by tonight.', time: '10:36 AM', isMe: false },
  { id: 6, sender: 'You', text: 'No rush! Thanks 😊', time: '10:37 AM', isMe: true },
  { id: 7, sender: 'Jane Smith', text: 'Did you pay the electricity bill?', time: '2m ago', isMe: false },
];

export function Chat() {
  const [newMessage, setNewMessage] = useState('');
  const [activeChat, setActiveChat] = useState(chats[0]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      // Handle send message
      setNewMessage('');
    }
  };

  return (
    <MainLayout>
      <div className="h-[calc(100vh-180px)]">
        <Card className="h-full flex overflow-hidden p-0">
          {/* Sidebar - Chat List */}
          <div className="w-80 border-r border-[rgba(148,163,184,0.1)] flex flex-col">
            {/* Search */}
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#94A3B8]" />
                <input
                  type="text"
                  placeholder="Search chats..."
                  className="w-full bg-[rgba(30,41,59,0.8)] border border-[rgba(148,163,184,0.1)] rounded-2xl pl-10 pr-4 py-2 text-[#EDE9FE] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#7C3AED] text-sm"
                />
              </div>
            </div>

            {/* Chat List */}
            <div className="flex-1 overflow-y-auto">
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => setActiveChat(chat)}
                  className={`p-4 border-b border-[rgba(148,163,184,0.05)] cursor-pointer transition-all ${
                    activeChat.id === chat.id
                      ? 'bg-[rgba(124,58,237,0.2)]'
                      : 'hover:bg-[rgba(30,41,59,0.4)]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-[#EDE9FE] truncate">{chat.name}</h4>
                        <span className="text-xs text-[#94A3B8]">{chat.time}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-[#94A3B8] truncate">{chat.lastMessage}</p>
                        {chat.unread > 0 && (
                          <span className="ml-2 w-5 h-5 bg-[#7C3AED] rounded-full flex items-center justify-center text-xs text-white flex-shrink-0">
                            {chat.unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Main Chat Area */}
          <div className="flex-1 flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b border-[rgba(148,163,184,0.1)] flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-[#EDE9FE]">{activeChat.name}</h3>
                <p className="text-xs text-[#94A3B8]">Active now</p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isMe ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-md ${message.isMe ? 'order-2' : 'order-1'}`}>
                    <div
                      className={`rounded-3xl px-5 py-3 ${
                        message.isMe
                          ? 'bg-gradient-to-r from-[#7C3AED] to-[#6D28D9] text-white'
                          : 'bg-[rgba(30,41,59,0.8)] text-[#EDE9FE]'
                      }`}
                    >
                      <p>{message.text}</p>
                    </div>
                    <p className={`text-xs text-[#94A3B8] mt-1 px-2 ${message.isMe ? 'text-right' : 'text-left'}`}>
                      {message.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input Area */}
            <div className="p-4 border-t border-[rgba(148,163,184,0.1)]">
              <form onSubmit={handleSendMessage} className="flex gap-3">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-[rgba(30,41,59,0.8)] border border-[rgba(148,163,184,0.1)] rounded-2xl px-4 py-3 text-[#EDE9FE] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#7C3AED]"
                />
                <Button type="submit">
                  <Send className="w-5 h-5" />
                </Button>
              </form>
            </div>
          </div>
        </Card>
      </div>
    </MainLayout>
  );
}
