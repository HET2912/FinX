import { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Button } from '../components/ui/Button';
import { User, Lock, Bell, Palette, Globe } from 'lucide-react';

const currencyOptions = [
  { value: 'usd', label: 'USD ($)' },
  { value: 'eur', label: 'EUR (€)' },
  { value: 'gbp', label: 'GBP (£)' },
  { value: 'inr', label: 'INR (₹)' },
];

const languageOptions = [
  { value: 'en', label: 'English' },
  { value: 'es', label: 'Spanish' },
  { value: 'fr', label: 'French' },
  { value: 'de', label: 'German' },
];

export function Settings() {
  const [profileData, setProfileData] = useState({
    name: 'John Doe',
    email: 'john@example.com',
    phone: '+1 234 567 8900'
  });

  const [passwordData, setPasswordData] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  const [preferences, setPreferences] = useState({
    currency: 'usd',
    language: 'en',
    notifications: {
      email: true,
      push: true,
      budgetAlerts: true,
      goalReminders: true,
      groupUpdates: true
    }
  });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle save profile
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle change password
    setPasswordData({ current: '', new: '', confirm: '' });
  };

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle save preferences
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl mb-2 text-[#EDE9FE]">Settings</h1>
          <p className="text-[#94A3B8]">Manage your account and preferences</p>
        </div>

        {/* Profile Settings */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#6D28D9] rounded-2xl flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl text-[#EDE9FE]">Profile Settings</h2>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-6">
            {/* Profile Picture */}
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-full flex items-center justify-center text-white text-3xl">
                JD
              </div>
              <div>
                <Button type="button" variant="secondary" size="sm">
                  Change Photo
                </Button>
                <p className="text-[#94A3B8] text-sm mt-2">JPG, PNG or GIF. Max size 2MB</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Full Name"
                type="text"
                value={profileData.name}
                onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
              />
              <Input
                label="Email"
                type="email"
                value={profileData.email}
                onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
              />
            </div>

            <Input
              label="Phone Number"
              type="tel"
              value={profileData.phone}
              onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
            />

            <Button type="submit">Save Changes</Button>
          </form>
        </Card>

        {/* Password Settings */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-[#22D3EE] to-[#06B6D4] rounded-2xl flex items-center justify-center">
              <Lock className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl text-[#EDE9FE]">Change Password</h2>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-6">
            <Input
              label="Current Password"
              type="password"
              placeholder="••••••••"
              value={passwordData.current}
              onChange={(e) => setPasswordData({ ...passwordData, current: e.target.value })}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="New Password"
                type="password"
                placeholder="••••••••"
                value={passwordData.new}
                onChange={(e) => setPasswordData({ ...passwordData, new: e.target.value })}
              />
              <Input
                label="Confirm New Password"
                type="password"
                placeholder="••••••••"
                value={passwordData.confirm}
                onChange={(e) => setPasswordData({ ...passwordData, confirm: e.target.value })}
              />
            </div>

            <Button type="submit">Update Password</Button>
          </form>
        </Card>

        {/* Preferences */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl flex items-center justify-center">
              <Palette className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl text-[#EDE9FE]">Preferences</h2>
          </div>

          <form onSubmit={handleSavePreferences} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select
                label="Currency"
                options={currencyOptions}
                value={preferences.currency}
                onChange={(e) => setPreferences({ ...preferences, currency: e.target.value })}
              />
              <Select
                label="Language"
                options={languageOptions}
                value={preferences.language}
                onChange={(e) => setPreferences({ ...preferences, language: e.target.value })}
              />
            </div>

            <Button type="submit">Save Preferences</Button>
          </form>
        </Card>

        {/* Notification Settings */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-2xl flex items-center justify-center">
              <Bell className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl text-[#EDE9FE]">Notifications</h2>
          </div>

          <div className="space-y-4">
            {/* Email Notifications */}
            <div className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl">
              <div>
                <h4 className="text-[#EDE9FE] mb-1">Email Notifications</h4>
                <p className="text-[#94A3B8] text-sm">Receive notifications via email</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.notifications.email}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    notifications: { ...preferences.notifications, email: e.target.checked }
                  })}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-[rgba(30,41,59,0.8)] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#7C3AED] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#7C3AED]"></div>
              </label>
            </div>

            {/* Push Notifications */}
            <div className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl">
              <div>
                <h4 className="text-[#EDE9FE] mb-1">Push Notifications</h4>
                <p className="text-[#94A3B8] text-sm">Receive push notifications on your device</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.notifications.push}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    notifications: { ...preferences.notifications, push: e.target.checked }
                  })}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-[rgba(30,41,59,0.8)] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#7C3AED] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#7C3AED]"></div>
              </label>
            </div>

            {/* Budget Alerts */}
            <div className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl">
              <div>
                <h4 className="text-[#EDE9FE] mb-1">Budget Alerts</h4>
                <p className="text-[#94A3B8] text-sm">Get notified when you exceed your budget</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.notifications.budgetAlerts}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    notifications: { ...preferences.notifications, budgetAlerts: e.target.checked }
                  })}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-[rgba(30,41,59,0.8)] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#7C3AED] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#7C3AED]"></div>
              </label>
            </div>

            {/* Goal Reminders */}
            <div className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl">
              <div>
                <h4 className="text-[#EDE9FE] mb-1">Goal Reminders</h4>
                <p className="text-[#94A3B8] text-sm">Reminders to help you reach your savings goals</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.notifications.goalReminders}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    notifications: { ...preferences.notifications, goalReminders: e.target.checked }
                  })}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-[rgba(30,41,59,0.8)] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#7C3AED] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#7C3AED]"></div>
              </label>
            </div>

            {/* Group Updates */}
            <div className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl">
              <div>
                <h4 className="text-[#EDE9FE] mb-1">Group Updates</h4>
                <p className="text-[#94A3B8] text-sm">Notifications from group expense activities</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.notifications.groupUpdates}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    notifications: { ...preferences.notifications, groupUpdates: e.target.checked }
                  })}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-[rgba(30,41,59,0.8)] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#7C3AED] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#7C3AED]"></div>
              </label>
            </div>
          </div>
        </Card>

        {/* Danger Zone */}
        <Card className="border-[#EF4444]/20">
          <h2 className="text-2xl text-[#EF4444] mb-4">Danger Zone</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-[rgba(239,68,68,0.1)] rounded-2xl">
              <div>
                <h4 className="text-[#EDE9FE] mb-1">Delete Account</h4>
                <p className="text-[#94A3B8] text-sm">Permanently delete your account and all data</p>
              </div>
              <Button variant="danger">Delete Account</Button>
            </div>
          </div>
        </Card>
      </div>
    </MainLayout>
  );
}
