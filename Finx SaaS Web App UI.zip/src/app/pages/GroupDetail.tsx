import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { ArrowLeft, Plus, User } from 'lucide-react';
import { useNavigate, useParams } from 'react-router';

const members = [
  { id: 1, name: 'John Doe', email: 'john@example.com', balance: 120, owes: true },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', balance: -80, owes: false },
  { id: 3, name: 'Mike Johnson', email: 'mike@example.com', balance: 45, owes: true },
  { id: 4, name: 'Sarah Williams', email: 'sarah@example.com', balance: -85, owes: false },
];

const expenses = [
  { id: 1, description: 'Rent Payment', amount: 1200, paidBy: 'John Doe', date: '2026-04-01', split: 4 },
  { id: 2, name: 'Electricity Bill', amount: 150, paidBy: 'Jane Smith', date: '2026-04-05', split: 4 },
  { id: 3, name: 'Internet', amount: 80, paidBy: 'John Doe', date: '2026-04-07', split: 4 },
  { id: 4, name: 'Groceries', amount: 320, paidBy: 'Mike Johnson', date: '2026-04-10', split: 4 },
  { id: 5, name: 'Water Bill', amount: 45, paidBy: 'Sarah Williams', date: '2026-04-12', split: 4 },
];

export function GroupDetail() {
  const navigate = useNavigate();
  const { id } = useParams();

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/groups')}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <div className="flex items-center gap-3">
                <span className="text-3xl">🏠</span>
                <h1 className="text-3xl text-[#EDE9FE]">Roommates</h1>
              </div>
              <p className="text-[#94A3B8] ml-12">4 members • Total: $2,450</p>
            </div>
          </div>
          <Button>
            <Plus className="w-5 h-5 mr-2" />
            Add Expense
          </Button>
        </div>

        {/* Balance Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-gradient-to-br from-[rgba(239,68,68,0.2)] to-[rgba(220,38,38,0.2)]">
            <h3 className="text-lg text-[#EDE9FE] mb-2">You Owe</h3>
            <p className="text-4xl text-[#EF4444] mb-2">$125.00</p>
            <p className="text-[#94A3B8]">To 2 people</p>
          </Card>

          <Card className="bg-gradient-to-br from-[rgba(16,185,129,0.2)] to-[rgba(5,150,105,0.2)]">
            <h3 className="text-lg text-[#EDE9FE] mb-2">You Are Owed</h3>
            <p className="text-4xl text-[#10B981] mb-2">$165.00</p>
            <p className="text-[#94A3B8]">From 2 people</p>
          </Card>
        </div>

        {/* Members */}
        <Card>
          <h3 className="text-xl text-[#EDE9FE] mb-6">Members & Balances</h3>
          <div className="space-y-3">
            {members.map((member) => (
              <div
                key={member.id}
                className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-[#EDE9FE]">{member.name}</p>
                    <p className="text-[#94A3B8] text-sm">{member.email}</p>
                  </div>
                </div>
                <div className="text-right">
                  {member.balance === 0 ? (
                    <span className="text-[#94A3B8]">Settled up</span>
                  ) : member.owes ? (
                    <div>
                      <p className="text-[#10B981] font-medium">owes you</p>
                      <p className="text-[#10B981]">${Math.abs(member.balance)}</p>
                    </div>
                  ) : (
                    <div>
                      <p className="text-[#EF4444] font-medium">you owe</p>
                      <p className="text-[#EF4444]">${Math.abs(member.balance)}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Expenses */}
        <Card>
          <h3 className="text-xl text-[#EDE9FE] mb-6">Shared Expenses</h3>
          <div className="space-y-3">
            {expenses.map((expense) => (
              <div
                key={expense.id}
                className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl hover:bg-[rgba(30,41,59,0.6)] transition-all"
              >
                <div>
                  <p className="text-[#EDE9FE]">{expense.description || expense.name}</p>
                  <p className="text-[#94A3B8] text-sm">
                    Paid by {expense.paidBy} • Split {expense.split} ways
                  </p>
                  <p className="text-[#94A3B8] text-xs mt-1">
                    {new Date(expense.date).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric', 
                      year: 'numeric' 
                    })}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[#EDE9FE] font-medium">${expense.amount}</p>
                  <p className="text-[#22D3EE] text-sm">
                    ${(expense.amount / expense.split).toFixed(2)} each
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Settle Up */}
        <Card className="bg-gradient-to-br from-[rgba(124,58,237,0.2)] to-[rgba(34,211,238,0.2)]">
          <div className="text-center">
            <h3 className="text-xl text-[#EDE9FE] mb-2">Ready to Settle Up?</h3>
            <p className="text-[#94A3B8] mb-6">
              Simplify your balances and settle with group members
            </p>
            <Button size="lg">
              Settle All Balances
            </Button>
          </div>
        </Card>
      </div>
    </MainLayout>
  );
}
