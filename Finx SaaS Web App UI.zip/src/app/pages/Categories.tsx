import { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { 
  Plus, 
  Edit, 
  Trash2, 
  ShoppingBag, 
  Coffee, 
  Car, 
  Home, 
  Zap, 
  Heart, 
  Plane,
  Film,
  Briefcase,
  TrendingUp
} from 'lucide-react';

const iconOptions = [
  { icon: ShoppingBag, name: 'ShoppingBag' },
  { icon: Coffee, name: 'Coffee' },
  { icon: Car, name: 'Car' },
  { icon: Home, name: 'Home' },
  { icon: Zap, name: 'Zap' },
  { icon: Heart, name: 'Heart' },
  { icon: Plane, name: 'Plane' },
  { icon: Film, name: 'Film' },
  { icon: Briefcase, name: 'Briefcase' },
  { icon: TrendingUp, name: 'TrendingUp' },
];

const categories = [
  { id: 1, name: 'Shopping', icon: ShoppingBag, color: '#7C3AED', type: 'expense', transactions: 45 },
  { id: 2, name: 'Food & Dining', icon: Coffee, color: '#22D3EE', type: 'expense', transactions: 89 },
  { id: 3, name: 'Transportation', icon: Car, color: '#10B981', type: 'expense', transactions: 32 },
  { id: 4, name: 'Housing', icon: Home, color: '#F59E0B', type: 'expense', transactions: 12 },
  { id: 5, name: 'Bills & Utilities', icon: Zap, color: '#EF4444', type: 'expense', transactions: 18 },
  { id: 6, name: 'Health & Fitness', icon: Heart, color: '#EC4899', type: 'expense', transactions: 24 },
  { id: 7, name: 'Travel', icon: Plane, color: '#8B5CF6', type: 'expense', transactions: 8 },
  { id: 8, name: 'Entertainment', icon: Film, color: '#F97316', type: 'expense', transactions: 36 },
  { id: 9, name: 'Salary', icon: Briefcase, color: '#10B981', type: 'income', transactions: 12 },
  { id: 10, name: 'Investment', icon: TrendingUp, color: '#22D3EE', type: 'income', transactions: 6 },
];

export function Categories() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedIcon, setSelectedIcon] = useState(0);
  const [newCategory, setNewCategory] = useState({
    name: '',
    color: '#7C3AED',
    type: 'expense'
  });

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAddModalOpen(false);
    setNewCategory({ name: '', color: '#7C3AED', type: 'expense' });
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Categories</h1>
            <p className="text-[#94A3B8]">Organize your transactions with custom categories</p>
          </div>
          <Button onClick={() => setIsAddModalOpen(true)}>
            <Plus className="w-5 h-5 mr-2" />
            Add Category
          </Button>
        </div>

        {/* Expense Categories */}
        <div>
          <h2 className="text-xl text-[#EDE9FE] mb-4">Expense Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.filter(cat => cat.type === 'expense').map((category) => (
              <Card key={category.id}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-2xl flex items-center justify-center"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      <category.icon className="w-6 h-6" style={{ color: category.color }} />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#EDE9FE]">{category.name}</h3>
                      <p className="text-sm text-[#94A3B8]">{category.transactions} transactions</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="flex-1">
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" className="text-[#EF4444] hover:bg-[#EF4444]/10">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Income Categories */}
        <div>
          <h2 className="text-xl text-[#EDE9FE] mb-4">Income Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.filter(cat => cat.type === 'income').map((category) => (
              <Card key={category.id}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-2xl flex items-center justify-center"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      <category.icon className="w-6 h-6" style={{ color: category.color }} />
                    </div>
                    <div>
                      <h3 className="text-lg text-[#EDE9FE]">{category.name}</h3>
                      <p className="text-sm text-[#94A3B8]">{category.transactions} transactions</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="flex-1">
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" className="text-[#EF4444] hover:bg-[#EF4444]/10">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Add Category Modal */}
        <Modal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          title="Create Category"
          size="md"
        >
          <form onSubmit={handleAddCategory} className="space-y-6">
            <Input
              label="Category Name"
              type="text"
              placeholder="e.g., Groceries"
              value={newCategory.name}
              onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
              required
            />

            <div>
              <label className="block text-[#CBD5E1] mb-2">Type</label>
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setNewCategory({ ...newCategory, type: 'expense' })}
                  className={`flex-1 py-3 rounded-2xl transition-all ${
                    newCategory.type === 'expense'
                      ? 'bg-[#EF4444] text-white'
                      : 'bg-[rgba(30,41,59,0.6)] text-[#94A3B8]'
                  }`}
                >
                  Expense
                </button>
                <button
                  type="button"
                  onClick={() => setNewCategory({ ...newCategory, type: 'income' })}
                  className={`flex-1 py-3 rounded-2xl transition-all ${
                    newCategory.type === 'income'
                      ? 'bg-[#10B981] text-white'
                      : 'bg-[rgba(30,41,59,0.6)] text-[#94A3B8]'
                  }`}
                >
                  Income
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[#CBD5E1] mb-3">Choose Icon</label>
              <div className="grid grid-cols-5 gap-3">
                {iconOptions.map((option, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => setSelectedIcon(index)}
                    className={`w-full aspect-square rounded-2xl flex items-center justify-center transition-all ${
                      selectedIcon === index
                        ? 'bg-[#7C3AED] text-white'
                        : 'bg-[rgba(30,41,59,0.6)] text-[#94A3B8] hover:bg-[rgba(30,41,59,0.8)]'
                    }`}
                  >
                    <option.icon className="w-6 h-6" />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[#CBD5E1] mb-3">Choose Color</label>
              <div className="grid grid-cols-6 gap-3">
                {['#7C3AED', '#22D3EE', '#10B981', '#F59E0B', '#EF4444', '#EC4899', '#8B5CF6', '#F97316'].map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setNewCategory({ ...newCategory, color })}
                    className={`w-full aspect-square rounded-2xl transition-all ${
                      newCategory.color === color ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1E293B]' : ''
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button type="button" variant="secondary" onClick={() => setIsAddModalOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                Create Category
              </Button>
            </div>
          </form>
        </Modal>
      </div>
    </MainLayout>
  );
}
