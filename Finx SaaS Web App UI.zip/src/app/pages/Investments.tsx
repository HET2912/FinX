import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Plus, TrendingUp, TrendingDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const stats = [
  { title: 'Total Invested', value: '$45,230', change: '+12.5%', isPositive: true },
  { title: 'Current Value', value: '$52,890', change: '+15.2%', isPositive: true },
  { title: 'Total Returns', value: '$7,660', change: '+16.9%', isPositive: true },
  { title: 'Today\'s Change', value: '+$420', change: '+0.8%', isPositive: true },
];

const investments = [
  { id: 1, name: 'Apple Inc.', symbol: 'AAPL', type: 'Stock', invested: 15000, current: 17850, change: 19.0 },
  { id: 2, name: 'Microsoft Corp.', symbol: 'MSFT', type: 'Stock', invested: 12000, current: 14280, change: 19.0 },
  { id: 3, name: 'Vanguard S&P 500', symbol: 'VOO', type: 'ETF', invested: 10000, current: 11200, change: 12.0 },
  { id: 4, name: 'Bitcoin', symbol: 'BTC', type: 'Crypto', invested: 5000, current: 6300, change: 26.0 },
  { id: 5, name: 'Tesla Inc.', symbol: 'TSLA', type: 'Stock', invested: 3230, current: 3260, change: 0.9 },
];

const growthData = [
  { month: 'Oct', value: 42000 },
  { month: 'Nov', value: 44500 },
  { month: 'Dec', value: 43800 },
  { month: 'Jan', value: 46200 },
  { month: 'Feb', value: 48500 },
  { month: 'Mar', value: 50100 },
  { month: 'Apr', value: 52890 },
];

export function Investments() {
  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Investment Portfolio</h1>
            <p className="text-[#94A3B8]">Track and manage your investments</p>
          </div>
          <Button>
            <Plus className="w-5 h-5 mr-2" />
            Add Investment
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <p className="text-[#94A3B8] text-sm mb-1">{stat.title}</p>
              <h3 className="text-2xl text-[#EDE9FE] mb-2">{stat.value}</h3>
              <div className="flex items-center gap-1">
                {stat.isPositive ? (
                  <TrendingUp className="w-4 h-4 text-[#10B981]" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-[#EF4444]" />
                )}
                <span className={stat.isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                  {stat.change}
                </span>
              </div>
            </Card>
          ))}
        </div>

        {/* Growth Chart */}
        <Card>
          <h3 className="text-xl text-[#EDE9FE] mb-6">Portfolio Growth</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={growthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.1)" />
              <XAxis dataKey="month" stroke="#94A3B8" />
              <YAxis stroke="#94A3B8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1E293B', 
                  border: '1px solid rgba(148,163,184,0.1)', 
                  borderRadius: '12px',
                  color: '#EDE9FE'
                }} 
              />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="#10B981" 
                strokeWidth={3} 
                dot={{ fill: '#10B981', r: 6 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Investments List */}
        <Card>
          <h3 className="text-xl text-[#EDE9FE] mb-6">My Investments</h3>
          <div className="space-y-4">
            {investments.map((investment) => (
              <div
                key={investment.id}
                className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl hover:bg-[rgba(30,41,59,0.6)] transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-2xl flex items-center justify-center">
                    <span className="text-white font-bold text-sm">{investment.symbol.substring(0, 2)}</span>
                  </div>
                  <div>
                    <h4 className="text-[#EDE9FE]">{investment.name}</h4>
                    <p className="text-[#94A3B8] text-sm">{investment.symbol} • {investment.type}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[#EDE9FE]">${investment.current.toLocaleString()}</p>
                  <div className="flex items-center gap-1 justify-end">
                    {investment.change >= 0 ? (
                      <TrendingUp className="w-4 h-4 text-[#10B981]" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-[#EF4444]" />
                    )}
                    <span className={investment.change >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                      {investment.change >= 0 ? '+' : ''}{investment.change}%
                    </span>
                  </div>
                </div>
                <div className="text-right ml-8">
                  <p className="text-[#94A3B8] text-sm">Invested</p>
                  <p className="text-[#CBD5E1]">${investment.invested.toLocaleString()}</p>
                </div>
                <div className="text-right ml-8">
                  <p className="text-[#94A3B8] text-sm">Profit/Loss</p>
                  <p className={investment.current - investment.invested >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                    {investment.current - investment.invested >= 0 ? '+' : ''}$
                    {(investment.current - investment.invested).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Portfolio Allocation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <h3 className="text-xl text-[#EDE9FE] mb-6">Asset Allocation</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-[#CBD5E1]">Stocks</span>
                  <span className="text-[#EDE9FE]">67%</span>
                </div>
                <div className="w-full h-3 bg-[rgba(30,41,59,0.6)] rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#7C3AED] to-[#6D28D9]" style={{ width: '67%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-[#CBD5E1]">ETFs</span>
                  <span className="text-[#EDE9FE]">22%</span>
                </div>
                <div className="w-full h-3 bg-[rgba(30,41,59,0.6)] rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#22D3EE] to-[#06B6D4]" style={{ width: '22%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-[#CBD5E1]">Crypto</span>
                  <span className="text-[#EDE9FE]">11%</span>
                </div>
                <div className="w-full h-3 bg-[rgba(30,41,59,0.6)] rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#D97706]" style={{ width: '11%' }}></div>
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <h3 className="text-xl text-[#EDE9FE] mb-6">Top Performers</h3>
            <div className="space-y-3">
              {investments.sort((a, b) => b.change - a.change).slice(0, 3).map((investment, index) => (
                <div key={investment.id} className="flex items-center justify-between p-3 bg-[rgba(30,41,59,0.4)] rounded-2xl">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-xl flex items-center justify-center text-white text-xs">
                      #{index + 1}
                    </div>
                    <div>
                      <p className="text-[#EDE9FE] text-sm">{investment.symbol}</p>
                      <p className="text-[#94A3B8] text-xs">{investment.type}</p>
                    </div>
                  </div>
                  <span className="text-[#10B981]">+{investment.change}%</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
