import { Card } from '../components/ui/Card';
import { MainLayout } from '../components/layout/MainLayout';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  PiggyBank, 
  ShoppingBag, 
  Coffee, 
  Home, 
  Car,
  Sparkles
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from 'recharts';

// Mock Data
const stats = [
  { title: 'Total Balance', value: '$45,231.89', change: '+20.1%', icon: Wallet, color: 'from-[#7C3AED] to-[#6D28D9]' },
  { title: 'Total Income', value: '$12,234.00', change: '+12.5%', icon: TrendingUp, color: 'from-[#10B981] to-[#059669]' },
  { title: 'Total Expenses', value: '$8,234.00', change: '-8.3%', icon: TrendingDown, color: 'from-[#EF4444] to-[#DC2626]' },
  { title: 'Savings', value: '$4,000.00', change: '+15.2%', icon: PiggyBank, color: 'from-[#22D3EE] to-[#06B6D4]' },
];

const categoryData = [
  { name: 'Shopping', value: 2500, color: '#7C3AED' },
  { name: 'Food', value: 1800, color: '#22D3EE' },
  { name: 'Transport', value: 1200, color: '#10B981' },
  { name: 'Bills', value: 1500, color: '#F59E0B' },
  { name: 'Entertainment', value: 800, color: '#EF4444' },
];

const monthlyData = [
  { month: 'Jan', income: 12000, expenses: 8000 },
  { month: 'Feb', income: 11500, expenses: 7500 },
  { month: 'Mar', income: 13000, expenses: 9000 },
  { month: 'Apr', income: 12500, expenses: 8500 },
  { month: 'May', income: 14000, expenses: 9500 },
  { month: 'Jun', income: 12234, expenses: 8234 },
];

const trendData = [
  { date: 'Mon', amount: 1200 },
  { date: 'Tue', amount: 1800 },
  { date: 'Wed', amount: 1400 },
  { date: 'Thu', amount: 2200 },
  { date: 'Fri', amount: 1600 },
  { date: 'Sat', amount: 2400 },
  { date: 'Sun', amount: 1900 },
];

const topCategories = [
  { name: 'Shopping', amount: '$2,500', icon: ShoppingBag, color: 'text-[#7C3AED]' },
  { name: 'Food & Dining', amount: '$1,800', icon: Coffee, color: 'text-[#22D3EE]' },
  { name: 'Housing', amount: '$1,500', icon: Home, color: 'text-[#10B981]' },
  { name: 'Transportation', amount: '$1,200', icon: Car, color: 'text-[#F59E0B]' },
];

const recentTransactions = [
  { id: 1, name: 'Netflix Subscription', amount: '-$15.99', category: 'Entertainment', date: 'Apr 14, 2026', type: 'expense' },
  { id: 2, name: 'Salary Deposit', amount: '+$5,500', category: 'Income', date: 'Apr 13, 2026', type: 'income' },
  { id: 3, name: 'Grocery Shopping', amount: '-$124.50', category: 'Food', date: 'Apr 12, 2026', type: 'expense' },
  { id: 4, name: 'Uber Ride', amount: '-$18.20', category: 'Transport', date: 'Apr 11, 2026', type: 'expense' },
  { id: 5, name: 'Freelance Project', amount: '+$2,400', category: 'Income', date: 'Apr 10, 2026', type: 'income' },
];

const aiInsights = [
  'You spent 15% more on dining out this month. Consider meal prepping to save money.',
  'Great job! Your savings increased by 20% compared to last month.',
  'Your electricity bill is higher than usual. Check for any appliances running unnecessarily.',
];

export function Dashboard() {
  return (
    <MainLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl mb-2 text-[#EDE9FE]">Dashboard</h1>
          <p className="text-[#94A3B8]">Welcome back, John! Here's your financial overview.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[#94A3B8] text-sm mb-1">{stat.title}</p>
                  <h3 className="text-2xl text-[#EDE9FE] mb-2">{stat.value}</h3>
                  <p className={`text-sm ${stat.change.startsWith('+') ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {stat.change} from last month
                  </p>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-2xl flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pie Chart - Category Expenses */}
          <Card>
            <h3 className="text-xl text-[#EDE9FE] mb-6">Expenses by Category</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1E293B', 
                    border: '1px solid rgba(148,163,184,0.1)', 
                    borderRadius: '12px',
                    color: '#EDE9FE'
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          {/* Bar Chart - Monthly Comparison */}
          <Card>
            <h3 className="text-xl text-[#EDE9FE] mb-6">Income vs Expenses</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.1)" />
                <XAxis dataKey="month" stroke="#94A3B8" />
                <YAxis stroke="#94A3B8" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1E293B', 
                    border: '1px solid rgba(148,163,184,0.1)', 
                    borderRadius: '12px',
                    color: '#EDE9FE'
                  }} 
                />
                <Legend />
                <Bar dataKey="income" fill="#10B981" radius={[8, 8, 0, 0]} />
                <Bar dataKey="expenses" fill="#EF4444" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Line Chart - Spending Trend */}
        <Card>
          <h3 className="text-xl text-[#EDE9FE] mb-6">Weekly Spending Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.1)" />
              <XAxis dataKey="date" stroke="#94A3B8" />
              <YAxis stroke="#94A3B8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1E293B', 
                  border: '1px solid rgba(148,163,184,0.1)', 
                  borderRadius: '12px',
                  color: '#EDE9FE'
                }} 
              />
              <Line type="monotone" dataKey="amount" stroke="#7C3AED" strokeWidth={3} dot={{ fill: '#7C3AED', r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Top Spending Categories */}
          <Card>
            <h3 className="text-xl text-[#EDE9FE] mb-6">Top Spending Categories</h3>
            <div className="space-y-4">
              {topCategories.map((category, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-[rgba(30,41,59,0.4)] rounded-2xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 bg-[rgba(30,41,59,0.8)] rounded-xl flex items-center justify-center ${category.color}`}>
                      <category.icon className="w-5 h-5" />
                    </div>
                    <span className="text-[#EDE9FE]">{category.name}</span>
                  </div>
                  <span className="text-[#EDE9FE]">{category.amount}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent Transactions */}
          <Card className="lg:col-span-2">
            <h3 className="text-xl text-[#EDE9FE] mb-6">Recent Transactions</h3>
            <div className="space-y-3">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-4 bg-[rgba(30,41,59,0.4)] rounded-2xl hover:bg-[rgba(30,41,59,0.6)] transition-all">
                  <div>
                    <p className="text-[#EDE9FE]">{transaction.name}</p>
                    <p className="text-[#94A3B8] text-sm">{transaction.category} • {transaction.date}</p>
                  </div>
                  <span className={`font-medium ${transaction.type === 'income' ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                    {transaction.amount}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* AI Insights */}
        <Card className="bg-gradient-to-br from-[rgba(124,58,237,0.2)] to-[rgba(34,211,238,0.2)]">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-2xl flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl text-[#EDE9FE] mb-4">AI Insights & Suggestions</h3>
              <ul className="space-y-3">
                {aiInsights.map((insight, index) => (
                  <li key={index} className="flex items-start gap-2 text-[#CBD5E1]">
                    <span className="text-[#22D3EE] mt-1">•</span>
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </MainLayout>
  );
}
