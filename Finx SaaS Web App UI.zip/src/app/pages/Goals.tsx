import { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { Plus, Target, Trophy } from 'lucide-react';

const goals = [
  { id: 1, name: 'New MacBook Pro', target: 3500, saved: 2800, emoji: '💻', dueDate: '2026-06-30' },
  { id: 2, name: 'Vacation to Bali', target: 5000, saved: 3200, emoji: '🏝️', dueDate: '2026-08-15' },
  { id: 3, name: 'Emergency Fund', target: 10000, saved: 7500, emoji: '🛡️', dueDate: '2026-12-31' },
  { id: 4, name: 'New Car Down Payment', target: 8000, saved: 2400, emoji: '🚗', dueDate: '2027-03-01' },
  { id: 5, name: 'Home Theater Setup', target: 2000, saved: 1650, emoji: '🎬', dueDate: '2026-07-20' },
  { id: 6, name: 'Camera Equipment', target: 1500, saved: 450, emoji: '📷', dueDate: '2026-09-10' },
];

export function Goals() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newGoal, setNewGoal] = useState({
    name: '',
    target: '',
    saved: '',
    emoji: '🎯',
    dueDate: ''
  });

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAddModalOpen(false);
    setNewGoal({ name: '', target: '', saved: '', emoji: '🎯', dueDate: '' });
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Savings Goals</h1>
            <p className="text-[#94A3B8]">Set goals and track your progress</p>
          </div>
          <Button onClick={() => setIsAddModalOpen(true)}>
            <Plus className="w-5 h-5 mr-2" />
            Add Goal
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#6D28D9] rounded-2xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[#94A3B8] text-sm">Total Goals</p>
                <p className="text-2xl text-[#EDE9FE]">{goals.length}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-[#22D3EE] to-[#06B6D4] rounded-2xl flex items-center justify-center">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[#94A3B8] text-sm">Total Target</p>
                <p className="text-2xl text-[#EDE9FE]">
                  ${goals.reduce((sum, goal) => sum + goal.target, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl flex items-center justify-center">
                <span className="text-2xl">💰</span>
              </div>
              <div>
                <p className="text-[#94A3B8] text-sm">Total Saved</p>
                <p className="text-2xl text-[#EDE9FE]">
                  ${goals.reduce((sum, goal) => sum + goal.saved, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Goals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal) => {
            const progress = (goal.saved / goal.target) * 100;
            const isCompleted = progress >= 100;
            
            return (
              <Card key={goal.id} className={isCompleted ? 'bg-gradient-to-br from-[rgba(16,185,129,0.2)] to-[rgba(5,150,105,0.2)]' : ''}>
                <div className="text-center mb-4">
                  <div className="text-5xl mb-3">{goal.emoji}</div>
                  <h3 className="text-xl text-[#EDE9FE] mb-1">{goal.name}</h3>
                  <p className="text-[#94A3B8] text-sm">
                    Due: {new Date(goal.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </p>
                </div>

                {/* Progress Info */}
                <div className="mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-[#CBD5E1] text-sm">Saved</span>
                    <span className="text-[#EDE9FE] font-medium">${goal.saved.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between mb-3">
                    <span className="text-[#94A3B8] text-sm">Target</span>
                    <span className="text-[#94A3B8]">${goal.target.toLocaleString()}</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="relative">
                    <div className="w-full h-4 bg-[rgba(30,41,59,0.8)] rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          isCompleted 
                            ? 'bg-gradient-to-r from-[#10B981] to-[#059669]' 
                            : 'bg-gradient-to-r from-[#7C3AED] to-[#22D3EE]'
                        }`}
                        style={{ width: `${Math.min(progress, 100)}%` }}
                      ></div>
                    </div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                      <span className="text-xs text-white font-medium">
                        {Math.round(progress)}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Remaining Amount */}
                <div className="bg-[rgba(30,41,59,0.4)] rounded-2xl p-3 mb-4 text-center">
                  {isCompleted ? (
                    <div className="flex items-center justify-center gap-2 text-[#10B981]">
                      <Trophy className="w-5 h-5" />
                      <span className="font-medium">Goal Achieved! 🎉</span>
                    </div>
                  ) : (
                    <>
                      <p className="text-[#94A3B8] text-sm">Remaining</p>
                      <p className="text-2xl text-[#EDE9FE] font-medium">
                        ${(goal.target - goal.saved).toLocaleString()}
                      </p>
                    </>
                  )}
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button variant="secondary" size="sm" className="flex-1">
                    Add Funds
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1">
                    Edit
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Add Goal Modal */}
        <Modal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          title="Create Savings Goal"
          size="md"
        >
          <form onSubmit={handleAddGoal} className="space-y-6">
            <Input
              label="Goal Name"
              type="text"
              placeholder="e.g., New Laptop"
              value={newGoal.name}
              onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Target Amount"
                type="number"
                placeholder="5000"
                value={newGoal.target}
                onChange={(e) => setNewGoal({ ...newGoal, target: e.target.value })}
                required
              />

              <Input
                label="Already Saved"
                type="number"
                placeholder="1000"
                value={newGoal.saved}
                onChange={(e) => setNewGoal({ ...newGoal, saved: e.target.value })}
              />
            </div>

            <Input
              label="Due Date"
              type="date"
              value={newGoal.dueDate}
              onChange={(e) => setNewGoal({ ...newGoal, dueDate: e.target.value })}
              required
            />

            <div>
              <label className="block text-[#CBD5E1] mb-3">Choose an Emoji</label>
              <div className="grid grid-cols-6 gap-2">
                {['🎯', '💻', '🏝️', '🚗', '🏠', '📱', '✈️', '💰', '🎮', '📷', '🎬', '🏋️'].map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => setNewGoal({ ...newGoal, emoji })}
                    className={`text-3xl p-3 rounded-2xl transition-all ${
                      newGoal.emoji === emoji
                        ? 'bg-[#7C3AED] scale-110'
                        : 'bg-[rgba(30,41,59,0.6)] hover:bg-[rgba(30,41,59,0.8)]'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button type="button" variant="secondary" onClick={() => setIsAddModalOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                Create Goal
              </Button>
            </div>
          </form>
        </Modal>
      </div>
    </MainLayout>
  );
}
