import { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Plus, Users, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router';

const groups = [
  { id: 1, name: 'Roommates', members: 4, totalExpenses: 2450, yourShare: 612.50, emoji: '🏠' },
  { id: 2, name: 'Weekend Trip', members: 6, totalExpenses: 1800, yourShare: 300, emoji: '✈️' },
  { id: 3, name: 'Office Lunch', members: 8, totalExpenses: 420, yourShare: 52.50, emoji: '🍕' },
  { id: 4, name: 'Birthday Party', members: 12, totalExpenses: 960, yourShare: 80, emoji: '🎉' },
];

export function GroupExpense() {
  const navigate = useNavigate();

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Group Expenses</h1>
            <p className="text-[#94A3B8]">Split bills and track shared expenses</p>
          </div>
          <Button>
            <Plus className="w-5 h-5 mr-2" />
            Create Group
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#6D28D9] rounded-2xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[#94A3B8] text-sm">Active Groups</p>
                <p className="text-2xl text-[#EDE9FE]">{groups.length}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#EF4444] to-[#DC2626] rounded-2xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[#94A3B8] text-sm">You Owe</p>
                <p className="text-2xl text-[#EF4444]">$245.00</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[#94A3B8] text-sm">You Are Owed</p>
                <p className="text-2xl text-[#10B981]">$320.00</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Groups List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {groups.map((group) => (
            <Card 
              key={group.id}
              onClick={() => navigate(`/groups/${group.id}`)}
              className="cursor-pointer"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-4xl">{group.emoji}</div>
                  <div>
                    <h3 className="text-xl text-[#EDE9FE]">{group.name}</h3>
                    <p className="text-[#94A3B8] text-sm">{group.members} members</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between p-3 bg-[rgba(30,41,59,0.4)] rounded-2xl">
                  <span className="text-[#94A3B8]">Total Expenses</span>
                  <span className="text-[#EDE9FE] font-medium">${group.totalExpenses.toLocaleString()}</span>
                </div>
                <div className="flex justify-between p-3 bg-[rgba(30,41,59,0.4)] rounded-2xl">
                  <span className="text-[#94A3B8]">Your Share</span>
                  <span className="text-[#22D3EE] font-medium">${group.yourShare.toFixed(2)}</span>
                </div>
              </div>

              <Button variant="secondary" size="sm" className="w-full mt-4">
                View Details
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}
