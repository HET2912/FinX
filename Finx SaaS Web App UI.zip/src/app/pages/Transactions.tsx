import { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Modal } from '../components/ui/Modal';
import { Plus, Paperclip, Filter, Download } from 'lucide-react';

const transactions = [
  { id: 1, amount: -15.99, type: 'expense', category: 'Entertainment', date: '2026-04-14', notes: 'Monthly subscription', hasAttachment: false },
  { id: 2, amount: 5500, type: 'income', category: 'Salary', date: '2026-04-13', notes: 'Monthly salary', hasAttachment: false },
  { id: 3, amount: -124.50, type: 'expense', category: 'Food', date: '2026-04-12', notes: 'Grocery shopping at Whole Foods', hasAttachment: true },
  { id: 4, amount: -18.20, type: 'expense', category: 'Transport', date: '2026-04-11', notes: 'Uber to office', hasAttachment: false },
  { id: 5, amount: 2400, type: 'income', category: 'Freelance', date: '2026-04-10', notes: 'Website design project', hasAttachment: true },
  { id: 6, amount: -89.99, type: 'expense', category: 'Shopping', date: '2026-04-09', notes: 'New shoes', hasAttachment: false },
  { id: 7, amount: -45.00, type: 'expense', category: 'Bills', date: '2026-04-08', notes: 'Internet bill', hasAttachment: true },
  { id: 8, amount: -200.00, type: 'expense', category: 'Health', date: '2026-04-07', notes: 'Gym membership', hasAttachment: false },
  { id: 9, amount: 150, type: 'income', category: 'Investment', date: '2026-04-06', notes: 'Stock dividends', hasAttachment: false },
  { id: 10, amount: -32.50, type: 'expense', category: 'Food', date: '2026-04-05', notes: 'Dinner with friends', hasAttachment: false },
];

const categoryOptions = [
  { value: 'all', label: 'All Categories' },
  { value: 'food', label: 'Food' },
  { value: 'transport', label: 'Transport' },
  { value: 'shopping', label: 'Shopping' },
  { value: 'bills', label: 'Bills' },
  { value: 'entertainment', label: 'Entertainment' },
  { value: 'health', label: 'Health' },
  { value: 'salary', label: 'Salary' },
  { value: 'freelance', label: 'Freelance' },
  { value: 'investment', label: 'Investment' },
];

const typeOptions = [
  { value: 'all', label: 'All Types' },
  { value: 'income', label: 'Income' },
  { value: 'expense', label: 'Expense' },
];

export function Transactions() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [filters, setFilters] = useState({
    category: 'all',
    type: 'all',
    dateFrom: '',
    dateTo: ''
  });

  const [newTransaction, setNewTransaction] = useState({
    amount: '',
    type: 'expense',
    category: 'food',
    date: new Date().toISOString().split('T')[0],
    notes: '',
  });

  const handleAddTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle add transaction
    setIsAddModalOpen(false);
    setNewTransaction({
      amount: '',
      type: 'expense',
      category: 'food',
      date: new Date().toISOString().split('T')[0],
      notes: '',
    });
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Transactions</h1>
            <p className="text-[#94A3B8]">Track all your income and expenses</p>
          </div>
          <Button onClick={() => setIsAddModalOpen(true)}>
            <Plus className="w-5 h-5 mr-2" />
            Add Transaction
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <div className="flex items-center gap-4 mb-6">
            <Filter className="w-5 h-5 text-[#94A3B8]" />
            <h3 className="text-lg text-[#EDE9FE]">Filters</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Select
              label="Category"
              options={categoryOptions}
              value={filters.category}
              onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            />
            <Select
              label="Type"
              options={typeOptions}
              value={filters.type}
              onChange={(e) => setFilters({ ...filters, type: e.target.value })}
            />
            <Input
              label="From Date"
              type="date"
              value={filters.dateFrom}
              onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
            />
            <Input
              label="To Date"
              type="date"
              value={filters.dateTo}
              onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
            />
          </div>
          <div className="flex gap-3 mt-4">
            <Button variant="secondary" size="sm">
              Apply Filters
            </Button>
            <Button variant="ghost" size="sm">
              Reset
            </Button>
            <Button variant="ghost" size="sm" className="ml-auto">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </Card>

        {/* Transactions Table */}
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[rgba(148,163,184,0.1)]">
                  <th className="text-left py-4 px-4 text-[#94A3B8]">Date</th>
                  <th className="text-left py-4 px-4 text-[#94A3B8]">Category</th>
                  <th className="text-left py-4 px-4 text-[#94A3B8]">Notes</th>
                  <th className="text-right py-4 px-4 text-[#94A3B8]">Amount</th>
                  <th className="text-center py-4 px-4 text-[#94A3B8]">Attachment</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((transaction) => (
                  <tr
                    key={transaction.id}
                    className="border-b border-[rgba(148,163,184,0.05)] hover:bg-[rgba(30,41,59,0.4)] transition-all cursor-pointer"
                  >
                    <td className="py-4 px-4 text-[#CBD5E1]">
                      {new Date(transaction.date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </td>
                    <td className="py-4 px-4">
                      <span className="px-3 py-1 bg-[rgba(124,58,237,0.2)] text-[#A78BFA] rounded-full text-sm">
                        {transaction.category}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-[#94A3B8]">{transaction.notes}</td>
                    <td className={`py-4 px-4 text-right font-medium ${
                      transaction.type === 'income' ? 'text-[#10B981]' : 'text-[#EF4444]'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'}${Math.abs(transaction.amount).toFixed(2)}
                    </td>
                    <td className="py-4 px-4 text-center">
                      {transaction.hasAttachment && (
                        <Paperclip className="w-4 h-4 text-[#94A3B8] mx-auto" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Add Transaction Modal */}
        <Modal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          title="Add Transaction"
          size="md"
        >
          <form onSubmit={handleAddTransaction} className="space-y-6">
            <Input
              label="Amount"
              type="number"
              placeholder="100.00"
              value={newTransaction.amount}
              onChange={(e) => setNewTransaction({ ...newTransaction, amount: e.target.value })}
              required
            />

            <div>
              <label className="block text-[#CBD5E1] mb-2">Type</label>
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setNewTransaction({ ...newTransaction, type: 'expense' })}
                  className={`flex-1 py-3 rounded-2xl transition-all ${
                    newTransaction.type === 'expense'
                      ? 'bg-[#EF4444] text-white'
                      : 'bg-[rgba(30,41,59,0.6)] text-[#94A3B8]'
                  }`}
                >
                  Expense
                </button>
                <button
                  type="button"
                  onClick={() => setNewTransaction({ ...newTransaction, type: 'income' })}
                  className={`flex-1 py-3 rounded-2xl transition-all ${
                    newTransaction.type === 'income'
                      ? 'bg-[#10B981] text-white'
                      : 'bg-[rgba(30,41,59,0.6)] text-[#94A3B8]'
                  }`}
                >
                  Income
                </button>
              </div>
            </div>

            <Select
              label="Category"
              options={categoryOptions.filter(opt => opt.value !== 'all')}
              value={newTransaction.category}
              onChange={(e) => setNewTransaction({ ...newTransaction, category: e.target.value })}
            />

            <Input
              label="Date"
              type="date"
              value={newTransaction.date}
              onChange={(e) => setNewTransaction({ ...newTransaction, date: e.target.value })}
              required
            />

            <div>
              <label className="block text-[#CBD5E1] mb-2">Notes</label>
              <textarea
                value={newTransaction.notes}
                onChange={(e) => setNewTransaction({ ...newTransaction, notes: e.target.value })}
                className="w-full bg-[rgba(30,41,59,0.6)] backdrop-blur-xl border border-[rgba(148,163,184,0.1)] rounded-2xl px-4 py-3 text-[#EDE9FE] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#7C3AED] focus:border-transparent transition-all min-h-[100px]"
                placeholder="Add notes about this transaction..."
              />
            </div>

            <div>
              <label className="block text-[#CBD5E1] mb-2">Upload Screenshot</label>
              <div className="border-2 border-dashed border-[rgba(148,163,184,0.2)] rounded-2xl p-8 text-center hover:border-[#7C3AED] transition-all cursor-pointer">
                <Paperclip className="w-8 h-8 text-[#94A3B8] mx-auto mb-2" />
                <p className="text-[#94A3B8] text-sm">Click to upload or drag and drop</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button type="button" variant="secondary" onClick={() => setIsAddModalOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                Add Transaction
              </Button>
            </div>
          </form>
        </Modal>
      </div>
    </MainLayout>
  );
}
