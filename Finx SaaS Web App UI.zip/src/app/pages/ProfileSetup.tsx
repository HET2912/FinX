import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Button } from '../components/ui/Button';
import { Sparkles } from 'lucide-react';

const incomeSourceOptions = [
  { value: 'salary', label: 'Salary' },
  { value: 'business', label: 'Business' },
  { value: 'freelance', label: 'Freelance' },
  { value: 'investment', label: 'Investment' },
  { value: 'other', label: 'Other' }
];

export function ProfileSetup() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: 'John Doe',
    email: 'john@example.com',
    incomeSource: 'salary',
    monthlyIncome: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#0F172A] flex items-center justify-center p-8">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-2xl flex items-center justify-center">
            <Sparkles className="w-7 h-7 text-white" />
          </div>
          <span className="text-3xl font-bold bg-gradient-to-r from-[#7C3AED] to-[#22D3EE] bg-clip-text text-transparent">
            Finx
          </span>
        </div>

        <div className="bg-[rgba(30,41,59,0.6)] backdrop-blur-xl border border-[rgba(148,163,184,0.1)] rounded-3xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl mb-2 text-[#EDE9FE]">Complete Your Profile</h1>
            <p className="text-[#94A3B8]">
              Help us personalize your experience
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Full Name"
                type="text"
                placeholder="John Doe"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />

              <Input
                label="Email"
                type="email"
                placeholder="john@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <Select
              label="Income Source"
              options={incomeSourceOptions}
              value={formData.incomeSource}
              onChange={(e) => setFormData({ ...formData, incomeSource: e.target.value })}
              required
            />

            <Input
              label="Monthly Income"
              type="number"
              placeholder="5000"
              value={formData.monthlyIncome}
              onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
              required
            />

            <div className="flex gap-4">
              <Button type="button" variant="secondary" className="flex-1" onClick={() => navigate('/login')}>
                Skip for Now
              </Button>
              <Button type="submit" className="flex-1">
                Complete Setup
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
