import { InputHTMLAttributes, forwardRef } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className = '', ...props }, ref) => {
    return (
      <div className="w-full">
        {label && (
          <label className="block text-[#CBD5E1] mb-2">
            {label}
          </label>
        )}
        <input
          ref={ref}
          className={`w-full bg-[rgba(30,41,59,0.6)] backdrop-blur-xl border border-[rgba(148,163,184,0.1)] rounded-2xl px-4 py-3 text-[#EDE9FE] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#7C3AED] focus:border-transparent transition-all ${className}`}
          {...props}
        />
        {error && (
          <p className="text-[#EF4444] text-sm mt-1">{error}</p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';
