import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}

export function Card({ children, className = '', onClick }: CardProps) {
  return (
    <div 
      onClick={onClick}
      className={`bg-[rgba(30,41,59,0.6)] backdrop-blur-xl border border-[rgba(148,163,184,0.1)] rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:brightness-110 ${className}`}
    >
      {children}
    </div>
  );
}
