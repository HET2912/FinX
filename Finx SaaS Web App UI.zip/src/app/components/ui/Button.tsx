import { ButtonHTMLAttributes } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
}

export function Button({ 
  variant = 'primary', 
  size = 'md', 
  className = '', 
  children, 
  ...props 
}: ButtonProps) {
  const baseStyles = 'rounded-2xl transition-all duration-200 font-medium';
  
  const variants = {
    primary: 'bg-[#7C3AED] text-[#EDE9FE] hover:brightness-110 shadow-lg shadow-violet-900/30',
    secondary: 'bg-[#334155] text-[#EDE9FE] hover:brightness-110',
    ghost: 'bg-transparent text-[#CBD5E1] hover:bg-[#334155]',
    danger: 'bg-[#EF4444] text-[#EDE9FE] hover:brightness-110'
  };
  
  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3',
    lg: 'px-8 py-4 text-lg'
  };
  
  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
