import { ReactNode } from 'react';
import { Sidebar } from './Sidebar';
import { TopNavbar } from './TopNavbar';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-[#0F172A]">
      <Sidebar />
      <TopNavbar />
      <main className="ml-72 pt-20">
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
