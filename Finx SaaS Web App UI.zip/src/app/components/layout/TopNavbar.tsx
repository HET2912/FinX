import { Search, Bell, Settings } from 'lucide-react';
import { Link } from 'react-router';

export function TopNavbar() {
  return (
    <header className="h-20 bg-[rgba(30,41,59,0.6)] backdrop-blur-xl border-b border-[rgba(148,163,184,0.1)] fixed top-0 left-72 right-0 z-40 flex items-center justify-between px-8">
      {/* Search Bar */}
      <div className="flex-1 max-w-xl">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#94A3B8]" />
          <input
            type="text"
            placeholder="Search transactions, categories..."
            className="w-full bg-[rgba(30,41,59,0.8)] border border-[rgba(148,163,184,0.1)] rounded-2xl pl-12 pr-4 py-3 text-[#EDE9FE] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#7C3AED] focus:border-transparent transition-all"
          />
        </div>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-4">
        {/* Notifications */}
        <Link
          to="/notifications"
          className="relative w-11 h-11 bg-[rgba(30,41,59,0.8)] border border-[rgba(148,163,184,0.1)] rounded-2xl flex items-center justify-center hover:brightness-110 transition-all"
        >
          <Bell className="w-5 h-5 text-[#94A3B8]" />
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#EF4444] rounded-full flex items-center justify-center text-xs text-white">
            3
          </span>
        </Link>

        {/* Settings */}
        <Link
          to="/settings"
          className="w-11 h-11 bg-[rgba(30,41,59,0.8)] border border-[rgba(148,163,184,0.1)] rounded-2xl flex items-center justify-center hover:brightness-110 transition-all"
        >
          <Settings className="w-5 h-5 text-[#94A3B8]" />
        </Link>

        {/* Profile */}
        <Link to="/settings" className="flex items-center gap-3 bg-[rgba(30,41,59,0.8)] border border-[rgba(148,163,184,0.1)] rounded-2xl px-4 py-2 hover:brightness-110 transition-all">
          <div className="w-8 h-8 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-full flex items-center justify-center text-white text-sm">
            JD
          </div>
          <span className="text-[#EDE9FE] text-sm">John Doe</span>
        </Link>
      </div>
    </header>
  );
}
