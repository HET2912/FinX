import { Link, useLocation } from 'react-router';
import { 
  LayoutDashboard, 
  ArrowLeftRight, 
  Tags, 
  TrendingUp, 
  Target, 
  Users, 
  MessageCircle, 
  Bell, 
  Settings,
  Sparkles
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Transactions', href: '/transactions', icon: ArrowLeftRight },
  { name: 'Categories', href: '/categories', icon: Tags },
  { name: 'Investments', href: '/investments', icon: TrendingUp },
  { name: 'Goals', href: '/goals', icon: Target },
  { name: 'Group Expense', href: '/groups', icon: Users },
  { name: 'Chat', href: '/chat', icon: MessageCircle },
  { name: 'Notifications', href: '/notifications', icon: Bell },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-72 h-screen bg-[rgba(30,41,59,0.8)] backdrop-blur-xl border-r border-[rgba(148,163,184,0.1)] fixed left-0 top-0 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-[rgba(148,163,184,0.1)]">
        <Link to="/dashboard" className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-2xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-bold bg-gradient-to-r from-[#7C3AED] to-[#22D3EE] bg-clip-text text-transparent">
            Finx
          </span>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = location.pathname === item.href;
          return (
            <Link
              key={item.name}
              to={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200 ${
                isActive
                  ? 'bg-[rgba(124,58,237,0.2)] text-[#EDE9FE] shadow-lg shadow-violet-900/20'
                  : 'text-[#94A3B8] hover:bg-[rgba(51,65,85,0.5)] hover:text-[#EDE9FE]'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>

      {/* User Card */}
      <div className="p-4 border-t border-[rgba(148,163,184,0.1)]">
        <div className="bg-[rgba(30,41,59,0.6)] rounded-2xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-[#7C3AED] to-[#22D3EE] rounded-full flex items-center justify-center text-white">
            JD
          </div>
          <div className="flex-1">
            <p className="text-[#EDE9FE] text-sm">John Doe</p>
            <p className="text-[#94A3B8] text-xs">john@finx.app</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
